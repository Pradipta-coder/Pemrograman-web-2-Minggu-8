<html>
<title>
    Gumawang Pradipta
</title>

<head>
   
</head>

<body>

    <center>
        <h2>Halaman Login</h2>
        <label>Selamat Datang</label>
    </center>
    <br>

    <table align="center">
        <form method="POST" action="proses.php">

            <tr>
                <td>Username</td>
                <td><input type="text" name="username"> </td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password"> </td>
            </tr>
             <tr>
                <td>Nama</td>
                <td><input type="text" name="name"> </td>
            </tr>
			 <tr>
                <td>Hak</td>
                <td><input type="text" name="hak"> </td>
            </tr>
            <tr>
                <td> 
                <td><input type="submit"  name="login" value="Login"></td>
				<td><INPUT TYPE="reset"value="Ulang"></td>
				</td>
            </tr>
        </form>

    </table>
</body>

</html>